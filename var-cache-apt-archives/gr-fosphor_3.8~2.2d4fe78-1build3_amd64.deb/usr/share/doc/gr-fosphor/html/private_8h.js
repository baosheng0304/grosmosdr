var private_8h =
[
    [ "FLG_FOSPHOR_USE_CLGL_SHARING", "private_8h.html#a157dc42e8ad33c9ddc2e4b168277dd05", null ],
    [ "FOSPHOR_FFT_LEN", "group__private.html#gab0a38e260a617839ffdc76f4f75d4e76", null ],
    [ "FOSPHOR_FFT_LEN_LOG", "group__private.html#gaa6664b931ea03416b5367e9574a3fb57", null ],
    [ "FOSPHOR_FFT_MAX_BATCH", "group__private.html#gace37713da1eff604f9b0d94bf84f7fd4", null ],
    [ "FOSPHOR_FFT_MULT_BATCH", "group__private.html#ga0b6990f69b8d3542991cb80f29738b6f", null ]
];