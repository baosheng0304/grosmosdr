var airspy__fir__kernels_8h =
[
    [ "KERNEL_16_110_LEN", "airspy__fir__kernels_8h.html#a8f612ca09c61775db5b4b85a4e6b523f", null ],
    [ "KERNEL_2_80_LEN", "airspy__fir__kernels_8h.html#a5e0715f3049da50a2e2bf0979e2de7bc", null ],
    [ "KERNEL_4_90_LEN", "airspy__fir__kernels_8h.html#a77807492b8517d986ea21870dbc1d482", null ],
    [ "KERNEL_8_100_LEN", "airspy__fir__kernels_8h.html#a04983e6cd9e1a313d225601b678c99df", null ],
    [ "KERNEL_16_110", "airspy__fir__kernels_8h.html#a4baad703b797e92926cfde670443e51e", null ],
    [ "KERNEL_2_80", "airspy__fir__kernels_8h.html#a43676f349c106e93929ccdededc3cc8c", null ],
    [ "KERNEL_4_90", "airspy__fir__kernels_8h.html#a09d9f222c8283cad959c9c009cb49d90", null ],
    [ "KERNEL_8_100", "airspy__fir__kernels_8h.html#a151898faf87f1e32541f6e097591af8c", null ]
];