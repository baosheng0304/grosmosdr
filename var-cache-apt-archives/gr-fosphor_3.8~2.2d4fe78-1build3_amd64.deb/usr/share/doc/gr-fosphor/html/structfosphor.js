var structfosphor =
[
    [ "buf_spectrum", "structfosphor.html#a3a2abf5cb003eb0b1769b95e3af2fce0", null ],
    [ "center", "structfosphor.html#aa963d27835e02ec31a4636de8d7c5b56", null ],
    [ "cl", "structfosphor.html#a9f231e1980a7453a871249bd9f992bc9", null ],
    [ "db_per_div", "structfosphor.html#a57cfbcf2627ce9f0cd047fda2ec9d500", null ],
    [ "db_ref", "structfosphor.html#aeb8ba963aaab9f9ba34ed2de0b8dec79", null ],
    [ "fft_win", "structfosphor.html#a980c8f058cce62554624d61ab067c917", null ],
    [ "flags", "structfosphor.html#aace75c81af62309e4167a9cf88add015", null ],
    [ "frequency", "structfosphor.html#a7b5b5e3306ec73b7d44c2985a4e117ab", null ],
    [ "gl", "structfosphor.html#aebc016ec57727d4fd4941a0a9459e911", null ],
    [ "img_histogram", "structfosphor.html#af49bc7188e88b0317d683aeaf332213c", null ],
    [ "img_waterfall", "structfosphor.html#a70dafc896b985299af6c887850266467", null ],
    [ "offset", "structfosphor.html#a5e5e2c529721015a44dd14f60301cdc8", null ],
    [ "power", "structfosphor.html#a5954fcdb67d3e9c7d0c532c03b038fb6", null ],
    [ "scale", "structfosphor.html#a09b17b1c74c6a3feafccf9df85a476a9", null ],
    [ "span", "structfosphor.html#abf6cd6b69941ee750a78bdad923854dc", null ]
];