var osmosdr__src__c_8h =
[
    [ "osmosdr_dev_t", "osmosdr__src__c_8h.html#ad0e04f2ffdc92c3e46e36880cb82c907", null ],
    [ "osmosdr_make_src_c", "osmosdr__src__c_8h.html#a9cfcb78fd74961b0112bf877c467a00e", null ]
];