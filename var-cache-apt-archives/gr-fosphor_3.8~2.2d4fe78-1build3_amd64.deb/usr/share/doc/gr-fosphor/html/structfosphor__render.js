var structfosphor__render =
[
    [ "_wf_pos", "structfosphor__render.html#a1ab8b54981d5a792e3e950b9989bf491", null ],
    [ "_x", "structfosphor__render.html#a927fed7c542fbe6806d2431f258922f6", null ],
    [ "_x_div", "structfosphor__render.html#af2c2bf57fa7c548439b34c7f370b93e6", null ],
    [ "_x_label", "structfosphor__render.html#a315850e33745be5c7bfce228abdd515c", null ],
    [ "_y_histo", "structfosphor__render.html#a7b28223ab9b89d41f608ebc115fa0011", null ],
    [ "_y_histo_div", "structfosphor__render.html#a38297423788f4f53e35ab4c97ca4078a", null ],
    [ "_y_label", "structfosphor__render.html#ab9b2c0f501f652efa267c98c62fa6442", null ],
    [ "_y_wf", "structfosphor__render.html#a7c518fea66b2afbb736ecf3f0646eb03", null ],
    [ "channels", "structfosphor__render.html#a89c669a6f4efb0b39b5139241e241ea4", null ],
    [ "freq_n_div", "structfosphor__render.html#ac8e02f03c531d96e91377e1e159483e9", null ],
    [ "freq_start", "structfosphor__render.html#ade11ed738f67d738b347700fae5aa50c", null ],
    [ "freq_stop", "structfosphor__render.html#a84503c2f365a6940ecf7662f581767de", null ],
    [ "height", "structfosphor__render.html#acae223089ce4531482411286063d9063", null ],
    [ "histo_wf_ratio", "structfosphor__render.html#a0605df5e6e495c60d17a5db8f4311201", null ],
    [ "options", "structfosphor__render.html#af7658e69c61fa299a1fc4f374b8f6d04", null ],
    [ "pos_x", "structfosphor__render.html#aa58f67b48f3bb36c9794149d3ca09af0", null ],
    [ "pos_y", "structfosphor__render.html#ab8b6186c770971c313ab38a8c321805f", null ],
    [ "wf_span", "structfosphor__render.html#afdccf2faaeda975b34509d2834ad1d9f", null ],
    [ "width", "structfosphor__render.html#a71c5db95024f7b01cc95785ccc9d156f", null ]
];