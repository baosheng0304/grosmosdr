# Soapy SDR plugin for Audio devices

## Dependencies

* SoapySDR - https://github.com/pothosware/SoapySDR/wiki
* rtaudio - https://www.music.mcgill.ca/~gary/rtaudio/
* hamlib - http://sourceforge.net/projects/hamlib/

## Documentation

* https://github.com/pothosware/SoapyAudio/wiki
