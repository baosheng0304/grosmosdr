var fosphor_8h =
[
    [ "FOSPHOR_MAX_CHANNELS", "group__fosphor.html#gaedd6ad7c9700c2ccdcccd7996429f38e", null ],
    [ "FRO_CHANNELS", "group__fosphor.html#gad68df2a88cc351218b45ed3b9dcdde51", null ],
    [ "FRO_COLOR_SCALE", "group__fosphor.html#ga000ba9c54a6274d112312f1411a47757", null ],
    [ "FRO_HISTO", "group__fosphor.html#ga55f8feaf4a9bfd3a3efbea67cecaa196", null ],
    [ "FRO_LABEL_FREQ", "group__fosphor.html#ga55591bc9da05e95a42780452d6961ae2", null ],
    [ "FRO_LABEL_PWR", "group__fosphor.html#ga3871f765f7adef34bda2112825119aee", null ],
    [ "FRO_LABEL_TIME", "group__fosphor.html#gaee363f2d8a14bc6dc6821c9a13c6f4bd", null ],
    [ "FRO_LIVE", "group__fosphor.html#ga5d8a0dac9a833371ffa8a97f77b2d469", null ],
    [ "FRO_MAX_HOLD", "group__fosphor.html#ga9cf8b1dd1d31391dfd2db58b567af6f9", null ],
    [ "FRO_WATERFALL", "group__fosphor.html#ga1c43f82be4293a59d3ee099f71a34985", null ],
    [ "fosphor_draw", "group__fosphor.html#ga4e74234112cd6405c5eaf6e07bfc6580", null ],
    [ "fosphor_init", "group__fosphor.html#gaac2e1e8ce3ce91bc189d4f31d8e8683d", null ],
    [ "fosphor_process", "group__fosphor.html#gad3659f03ac52be63ebef42503828c3e1", null ],
    [ "fosphor_release", "group__fosphor.html#gabd56acf37f3b38434fad8a29a6501f56", null ],
    [ "fosphor_render_defaults", "group__fosphor.html#ga534569442f1a681e76e8bd7ecffa77f5", null ],
    [ "fosphor_render_refresh", "group__fosphor.html#gaeef67768d53a7d94fb283ecdfab40e27", null ],
    [ "fosphor_set_fft_window", "group__fosphor.html#ga45baf637dae9cc7471d47e9c80335271", null ],
    [ "fosphor_set_fft_window_default", "group__fosphor.html#ga975afdce7ec6563366483c59bd03da7c", null ],
    [ "fosphor_set_frequency_range", "group__fosphor.html#gab054a351747cb0869cb6d93ec2524ff7", null ],
    [ "fosphor_set_power_range", "group__fosphor.html#ga0a8b0172fb58bd496f893640d940f97e", null ]
];