# Public keys for VOLK

We publish the keys that are used to sign VOLK releases.

These keys are generated with [OpenBSD signify](https://www.openbsd.org/papers/bsdcan-signify.html).
On Ubuntu you can find this tool in the `signify-openbsd` package.