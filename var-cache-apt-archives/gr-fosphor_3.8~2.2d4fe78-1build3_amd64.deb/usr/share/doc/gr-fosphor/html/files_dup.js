var files_dup =
[
    [ "api.h", "api_8h.html", "api_8h" ],
    [ "axis.h", "axis_8h.html", "axis_8h" ],
    [ "base_sink_c.h", "base__sink__c_8h.html", null ],
    [ "base_sink_c_impl.h", "base__sink__c__impl_8h.html", null ],
    [ "cl.h", "cl_8h.html", "cl_8h" ],
    [ "cl_compat.h", "cl__compat_8h.html", "cl__compat_8h" ],
    [ "cl_platform.h", "cl__platform_8h.html", "cl__platform_8h" ],
    [ "fifo.h", "fifo_8h.html", [
      [ "fifo", "classgr_1_1fosphor_1_1fifo.html", "classgr_1_1fosphor_1_1fifo" ]
    ] ],
    [ "fosphor.h", "fosphor_8h.html", "fosphor_8h" ],
    [ "gl.h", "gl_8h.html", "gl_8h" ],
    [ "gl_cmap.h", "gl__cmap_8h.html", "gl__cmap_8h" ],
    [ "gl_cmap_gen.h", "gl__cmap__gen_8h.html", "gl__cmap__gen_8h" ],
    [ "gl_font.h", "gl__font_8h.html", "gl__font_8h" ],
    [ "gl_platform.h", "gl__platform_8h.html", "gl__platform_8h" ],
    [ "glfw_sink_c.h", "glfw__sink__c_8h.html", null ],
    [ "glfw_sink_c_impl.h", "glfw__sink__c__impl_8h.html", null ],
    [ "llist.h", "llist_8h.html", "llist_8h" ],
    [ "moc_predefs.h", "moc__predefs_8h.html", "moc__predefs_8h" ],
    [ "private.h", "private_8h.html", "private_8h" ],
    [ "QGLSurface.h", "QGLSurface_8h.html", [
      [ "QGLSurface", "classgr_1_1fosphor_1_1QGLSurface.html", "classgr_1_1fosphor_1_1QGLSurface" ]
    ] ],
    [ "qt_sink_c.h", "qt__sink__c_8h.html", null ],
    [ "qt_sink_c_impl.h", "qt__sink__c__impl_8h.html", null ],
    [ "resource.h", "resource_8h.html", "resource_8h" ],
    [ "resource_internal.h", "resource__internal_8h.html", "resource__internal_8h" ]
];