## Usage
To build tests with bazel
```sh
bazel test -s --verbose_failures //...
```
