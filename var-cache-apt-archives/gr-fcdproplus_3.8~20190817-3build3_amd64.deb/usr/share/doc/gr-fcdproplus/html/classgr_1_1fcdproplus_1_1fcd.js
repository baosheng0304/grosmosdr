var classgr_1_1fcdproplus_1_1fcd =
[
    [ "sptr", "classgr_1_1fcdproplus_1_1fcd.html#abd9e2b432147010efd54dde6005b3a8c", null ],
    [ "make", "classgr_1_1fcdproplus_1_1fcd.html#a41f0527b79ce7635c90da5a7af59e44b", null ],
    [ "set_dc_corr", "classgr_1_1fcdproplus_1_1fcd.html#a14eaadd12fc009bc64a468889153e0e8", null ],
    [ "set_freq", "classgr_1_1fcdproplus_1_1fcd.html#a9bb6a89df9feea729295ae3a5eb12b70", null ],
    [ "set_freq_corr", "classgr_1_1fcdproplus_1_1fcd.html#adabed9453ccc14bc98ce257dc1558688", null ],
    [ "set_iq_corr", "classgr_1_1fcdproplus_1_1fcd.html#a1cf4cbde743e102cb98ff1b7d08791bf", null ],
    [ "set_lna_gain", "classgr_1_1fcdproplus_1_1fcd.html#aee1bacc573748bc4f3bcd20ff6f7f97d", null ],
    [ "set_mixer_gain", "classgr_1_1fcdproplus_1_1fcd.html#afe06e0d506187d0c3600b61193bde22e", null ]
];