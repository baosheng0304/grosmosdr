var classgr_1_1fosphor_1_1base__sink__c =
[
    [ "ui_action_t", "classgr_1_1fosphor_1_1base__sink__c.html#a46f6c88c09f6e4cdec7fac34ce2c1557", [
      [ "DB_PER_DIV_UP", "classgr_1_1fosphor_1_1base__sink__c.html#a46f6c88c09f6e4cdec7fac34ce2c1557a3b9d02201a00b13dd100fc04a8c56ff1", null ],
      [ "DB_PER_DIV_DOWN", "classgr_1_1fosphor_1_1base__sink__c.html#a46f6c88c09f6e4cdec7fac34ce2c1557a71b7dcdeaa5a195b7dea2df668f964bc", null ],
      [ "REF_UP", "classgr_1_1fosphor_1_1base__sink__c.html#a46f6c88c09f6e4cdec7fac34ce2c1557a04d4579ff88b1864e5099bbff2021ae0", null ],
      [ "REF_DOWN", "classgr_1_1fosphor_1_1base__sink__c.html#a46f6c88c09f6e4cdec7fac34ce2c1557a93e956e031b86ea4c204016b4850cb3d", null ],
      [ "ZOOM_TOGGLE", "classgr_1_1fosphor_1_1base__sink__c.html#a46f6c88c09f6e4cdec7fac34ce2c1557a7d82910cc5e9f857290613964a8bad04", null ],
      [ "ZOOM_WIDTH_UP", "classgr_1_1fosphor_1_1base__sink__c.html#a46f6c88c09f6e4cdec7fac34ce2c1557ab4f8b1a705527e7899bb71181bdd8d5e", null ],
      [ "ZOOM_WIDTH_DOWN", "classgr_1_1fosphor_1_1base__sink__c.html#a46f6c88c09f6e4cdec7fac34ce2c1557a8c73ea2f8e87dc71da1ebf4999b54942", null ],
      [ "ZOOM_CENTER_UP", "classgr_1_1fosphor_1_1base__sink__c.html#a46f6c88c09f6e4cdec7fac34ce2c1557a13396626b69a7596df74f8dbe1df451c", null ],
      [ "ZOOM_CENTER_DOWN", "classgr_1_1fosphor_1_1base__sink__c.html#a46f6c88c09f6e4cdec7fac34ce2c1557aa2e4b3ff8c1b700168bef93cf9007700", null ],
      [ "RATIO_UP", "classgr_1_1fosphor_1_1base__sink__c.html#a46f6c88c09f6e4cdec7fac34ce2c1557ab4e7a892e0708fcabb6c05c340936521", null ],
      [ "RATIO_DOWN", "classgr_1_1fosphor_1_1base__sink__c.html#a46f6c88c09f6e4cdec7fac34ce2c1557aa2b7ff9c65e6266eb5b64e8be1c43391", null ],
      [ "FREEZE_TOGGLE", "classgr_1_1fosphor_1_1base__sink__c.html#a46f6c88c09f6e4cdec7fac34ce2c1557a8afc4d52272ef4e0025ec2a5f075b041", null ]
    ] ],
    [ "base_sink_c", "classgr_1_1fosphor_1_1base__sink__c.html#a66fb4e7fcf3f8e2407e8e659718b4c72", null ],
    [ "execute_ui_action", "classgr_1_1fosphor_1_1base__sink__c.html#a4da423311fd7f9c8e5dcbfa2139b13d2", null ],
    [ "set_fft_window", "classgr_1_1fosphor_1_1base__sink__c.html#ae14a6f44c8be2579635f876032e4887c", null ],
    [ "set_frequency_center", "classgr_1_1fosphor_1_1base__sink__c.html#ad5b0c4fbcf9b519e9a8ae6d5ceb59eb5", null ],
    [ "set_frequency_range", "classgr_1_1fosphor_1_1base__sink__c.html#abf470915c411a698dc4b4632fdf375f3", null ],
    [ "set_frequency_span", "classgr_1_1fosphor_1_1base__sink__c.html#ad722ed10842a3bace22a40956fcdbd95", null ]
];