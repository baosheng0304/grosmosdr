# Soapy SDR plugin for Airspy

## Dependencies

* SoapySDR - https://github.com/pothosware/SoapySDR/wiki
* libairspy - https://github.com/airspy/host/wiki

## Documentation

* https://github.com/pothosware/SoapyAirspy/wiki
