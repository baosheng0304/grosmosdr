var globals_dup =
[
    [ "_", "globals.html", null ],
    [ "a", "globals_a.html", null ],
    [ "b", "globals_b.html", null ],
    [ "c", "globals_c.html", null ],
    [ "e", "globals_e.html", null ],
    [ "f", "globals_f.html", null ],
    [ "g", "globals_g.html", null ],
    [ "l", "globals_l.html", null ],
    [ "q", "globals_q.html", null ],
    [ "r", "globals_r.html", null ],
    [ "s", "globals_s.html", null ],
    [ "u", "globals_u.html", null ]
];