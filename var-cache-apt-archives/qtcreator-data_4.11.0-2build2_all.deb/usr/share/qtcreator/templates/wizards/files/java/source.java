public class %{ClassName} {

}
