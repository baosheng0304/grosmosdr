var classgr_1_1fosphor_1_1glfw__sink__c =
[
    [ "sptr", "classgr_1_1fosphor_1_1glfw__sink__c.html#a43b3ff5f1ac0ecc93770804f3fd52596", null ],
    [ "make", "classgr_1_1fosphor_1_1glfw__sink__c.html#a1c648337ab2b335befd0afeaccc1cd44", null ]
];