var resource_8h =
[
    [ "resource_get", "group__resource.html#gaa86c37f369d01ce8adcef9b9e8a90bc2", null ],
    [ "resource_put", "group__resource.html#ga8e28d6bf1ded21d74f0aa579abde916c", null ]
];