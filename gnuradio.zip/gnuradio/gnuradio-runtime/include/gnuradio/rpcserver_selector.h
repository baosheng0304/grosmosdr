/* -*- c++ -*- */
/*
 * Copyright 2012 Free Software Foundation, Inc.
 *
 * This file is part of GNU Radio
 *
 * SPDX-License-Identifier: GPL-3.0-or-later
 *
 */

#ifndef RPCSERVER_SELECTOR
#define RPCSERVER_SELECTOR

#include <gnuradio/config.h>

//#define GR_RPCSERVER_ENABLED
//#define GR_RPCSERVER_ICE
//#define GR_RPCSERVER_THRIFT
//#define GR_RPCSERVER_ERLANG
//#define GR_RPCSERVER_XMLRPC

#endif
