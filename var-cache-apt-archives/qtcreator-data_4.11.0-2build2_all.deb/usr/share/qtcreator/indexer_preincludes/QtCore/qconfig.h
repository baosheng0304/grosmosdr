#include_next <QtCore/qconfig.h>
#undef QT_REDUCE_RELOCATIONS
