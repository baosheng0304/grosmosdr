var gl__font_8h =
[
    [ "ATTR_FORMAT", "group__gl.html#ga258941fa7002003d7c79d1ceec160afd", null ],
    [ "GLF_FLG_LCD", "group__gl.html#gacfc2b16e6b53cb6f691214170be0403a", null ],
    [ "glf_align", "group__gl.html#ga585e1c5b299285d00c200410f3735487", [
      [ "GLF_LEFT", "group__gl.html#gga585e1c5b299285d00c200410f3735487ada042edd1204e6bf67ee7fdc84c71196", null ],
      [ "GLF_RIGHT", "group__gl.html#gga585e1c5b299285d00c200410f3735487a29208e9c29cc2009d367a898646acf46", null ],
      [ "GLF_TOP", "group__gl.html#gga585e1c5b299285d00c200410f3735487accac15f381a66b94a6bc00469bc0bcd6", null ],
      [ "GLF_BOTTOM", "group__gl.html#gga585e1c5b299285d00c200410f3735487aa596a6d99893d2c5e55ebf3925491f34", null ],
      [ "GLF_CENTER", "group__gl.html#gga585e1c5b299285d00c200410f3735487a642e9c269f29171d701cd857abbd5fa5", null ]
    ] ],
    [ "glf_alloc", "group__gl.html#gaeffa054b3814734d97b3093443a33a04", null ],
    [ "glf_begin", "group__gl.html#ga7172711005b687735a05861c43e7edce", null ],
    [ "glf_draw_str", "group__gl.html#ga9b4a6741ba6db3f732e63b79e30de746", null ],
    [ "glf_end", "group__gl.html#ga1d2abd0f6d26762e455d1aa1b5ec67ae", null ],
    [ "glf_free", "group__gl.html#gac32f8d428b04059a4f38a22f0241bd3d", null ],
    [ "glf_load_face_file", "group__gl.html#ga1ec13b7d5427e37cb6c2edc05e70f1e5", null ],
    [ "glf_load_face_mem", "group__gl.html#ga5016ec5fb2c3ff1a1ba1d4d6f8380451", null ],
    [ "glf_printf", "group__gl.html#ga418da7befbcb3a8bc61c41d9112d2325", null ],
    [ "glf_width_str", "group__gl.html#ga1d309e7548fd0db0cd7684b7713360ea", null ]
];