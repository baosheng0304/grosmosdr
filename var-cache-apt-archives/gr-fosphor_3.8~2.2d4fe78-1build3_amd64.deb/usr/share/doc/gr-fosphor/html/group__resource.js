var group__resource =
[
    [ "resource.h", "resource_8h.html", null ],
    [ "resource_internal.h", "resource__internal_8h.html", null ],
    [ "resource_pack", "structresource__pack.html", [
      [ "data", "structresource__pack.html#a230b43a11f006e562dffb1bfdea87f8f", null ],
      [ "len", "structresource__pack.html#a8bfba72794a61a27dd79ca6aa9c67f7e", null ],
      [ "name", "structresource__pack.html#a7ad5993242de5ae068397338cae0dad6", null ]
    ] ],
    [ "resource_cache", "structresource__cache.html", [
      [ "data", "structresource__cache.html#a58b2982d83aef81fe61352c75d8b4836", null ],
      [ "extra", "structresource__cache.html#afcf4c8cc29b9549059ba957eaa5bddd8", null ],
      [ "flags", "structresource__cache.html#a95a5ee83d7e0328e8071c1c8a7b52c5d", null ],
      [ "head", "structresource__cache.html#a94e1c605a59b954de070d8f9c78f64d0", null ],
      [ "len", "structresource__cache.html#a52e30f29428f2361f6d86300ce3388b4", null ],
      [ "name", "structresource__cache.html#ab122401eec05031a49c61cd01787ad12", null ],
      [ "refcnt", "structresource__cache.html#a5a8546427cb434726ab92b2ac21df173", null ]
    ] ],
    [ "resource_get", "group__resource.html#gaa86c37f369d01ce8adcef9b9e8a90bc2", null ],
    [ "resource_put", "group__resource.html#ga8e28d6bf1ded21d74f0aa579abde916c", null ]
];