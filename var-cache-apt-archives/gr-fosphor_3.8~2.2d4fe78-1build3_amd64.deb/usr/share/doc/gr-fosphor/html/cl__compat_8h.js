var cl__compat_8h =
[
    [ "_cl_image_desc", "struct__cl__image__desc.html", "struct__cl__image__desc" ],
    [ "CL_DEVICE_COMPUTE_CAPABILITY_MAJOR_NV", "cl__compat_8h.html#adfcfc92c613a82896890f03f2925a61b", null ],
    [ "CL_DEVICE_COMPUTE_CAPABILITY_MINOR_NV", "cl__compat_8h.html#a7eaf49a47b7d793d1578fe4996240526", null ],
    [ "cl_image_desc", "cl__compat_8h.html#ad15efddb47f2b2108d3b53bfe19d1e8d", null ],
    [ "cl_compat_check_platform", "cl__compat_8h.html#a55f4a12fdb39942d66a0295fd2f13f87", null ],
    [ "cl_compat_init", "cl__compat_8h.html#a41377e78fe178e7e2f25d646e7d0fc6a", null ],
    [ "clCreateFromGLTexture", "cl__compat_8h.html#ac1395149b176ae99f6646eccad8ed2ce", null ],
    [ "clCreateImage", "cl__compat_8h.html#a726af6ab1921b7f4609a2f535e916dce", null ],
    [ "clEnqueueFillBuffer", "cl__compat_8h.html#a7ad71b90fb05edb7b16c25d7a286490c", null ],
    [ "clEnqueueFillImage", "cl__compat_8h.html#a591562d7f882ce7938692f98e8da7d91", null ]
];