var classgr_1_1fcdproplus_1_1fcdproplus =
[
    [ "sptr", "classgr_1_1fcdproplus_1_1fcdproplus.html#aecfbd15d08a9500223ac75bee3a493c4", null ],
    [ "make", "classgr_1_1fcdproplus_1_1fcdproplus.html#a43b18abe293f09b406ff113bd8a7ae5f", null ],
    [ "set_freq", "classgr_1_1fcdproplus_1_1fcdproplus.html#a9da58f91e3c6ee69f380d2f4eb5c997a", null ],
    [ "set_freq_corr", "classgr_1_1fcdproplus_1_1fcdproplus.html#abe8d939abb9796260b052c11e658bddf", null ],
    [ "set_if_gain", "classgr_1_1fcdproplus_1_1fcdproplus.html#ae931b647f16d552a725b0f9ee406aa5a", null ],
    [ "set_lna", "classgr_1_1fcdproplus_1_1fcdproplus.html#a0b8e92206019aa63e68125d4a6705280", null ],
    [ "set_mixer_gain", "classgr_1_1fcdproplus_1_1fcdproplus.html#a4300449c9276498849c929f7e30189aa", null ]
];