var modules =
[
    [ "hidapi API", "group__API.html", "group__API" ]
];