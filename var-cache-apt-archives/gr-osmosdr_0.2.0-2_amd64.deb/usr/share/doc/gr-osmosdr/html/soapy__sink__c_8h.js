var soapy__sink__c_8h =
[
    [ "soapy_sink_c", "classsoapy__sink__c.html", "classsoapy__sink__c" ],
    [ "make_soapy_sink_c", "soapy__sink__c_8h.html#a10ee8e0f612dfaa2ccf9151cc4832e4d", null ]
];