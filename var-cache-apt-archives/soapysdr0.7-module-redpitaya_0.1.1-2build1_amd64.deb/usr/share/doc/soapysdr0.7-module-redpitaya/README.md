# Soapy SDR module for Red Pitaya

## Build Status

- Travis: [![Travis Build Status](https://travis-ci.org/pothosware/SoapyRedPitaya.svg?branch=master)](https://travis-ci.org/pothosware/SoapyRedPitaya)

## Dependencies

* SoapySDR - https://github.com/pothosware/SoapySDR/wiki

## Documentation

* https://github.com/pothosware/SoapyRedPitaya/wiki
