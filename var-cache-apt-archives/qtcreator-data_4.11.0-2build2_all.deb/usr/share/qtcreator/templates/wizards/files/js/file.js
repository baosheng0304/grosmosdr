@if %{Stateless}
.pragma library

@endif
function func() {

}
