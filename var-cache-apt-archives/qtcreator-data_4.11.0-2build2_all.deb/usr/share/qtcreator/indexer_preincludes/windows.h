#pragma once

#include_next <windows.h>

// add here all dangerous defines
#undef small
