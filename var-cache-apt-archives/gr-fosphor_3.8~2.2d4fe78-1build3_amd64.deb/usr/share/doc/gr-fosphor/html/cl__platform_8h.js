var cl__platform_8h =
[
    [ "CL_TARGET_OPENCL_VERSION", "cl__platform_8h.html#a5990dea19d4ccb046a3d81b311457add", null ],
    [ "CL_USE_DEPRECATED_OPENCL_1_1_APIS", "cl__platform_8h.html#ab72d934d8b9c589a6360b45c2972386f", null ],
    [ "CL_USE_DEPRECATED_OPENCL_1_2_APIS", "cl__platform_8h.html#a16605039b395344c0b68b435e197b8bd", null ]
];