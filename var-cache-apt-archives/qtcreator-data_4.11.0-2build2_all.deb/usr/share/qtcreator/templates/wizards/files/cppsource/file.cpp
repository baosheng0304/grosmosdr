%{Cpp:LicenseTemplate}\
