var structllist__head =
[
    [ "next", "structllist__head.html#a9a6ee80976fe50c0c52c96dae6f1701b", null ],
    [ "prev", "structllist__head.html#afd9f989105cb76e5b8d5cbbdf0557fb4", null ]
];