var hierarchy =
[
    [ "block", null, [
      [ "gr::fcdproplus::fcdpp_control", "classgr_1_1fcdproplus_1_1fcdpp__control.html", [
        [ "gr::fcdproplus::fcdpp_control_impl", "classgr_1_1fcdproplus_1_1fcdpp__control__impl.html", null ]
      ] ]
    ] ],
    [ "block", null, [
      [ "gr::fcdproplus::fcd_control", "classgr_1_1fcdproplus_1_1fcd__control.html", [
        [ "gr::fcdproplus::fcd_control_impl", "classgr_1_1fcdproplus_1_1fcd__control__impl.html", null ]
      ] ]
    ] ],
    [ "hid_device_info", "structhid__device__info.html", null ],
    [ "hier_block2", null, [
      [ "gr::fcdproplus::fcdproplus", "classgr_1_1fcdproplus_1_1fcdproplus.html", [
        [ "gr::fcdproplus::fcdproplus_impl", "classgr_1_1fcdproplus_1_1fcdproplus__impl.html", null ]
      ] ]
    ] ],
    [ "hier_block2", null, [
      [ "gr::fcdproplus::fcd", "classgr_1_1fcdproplus_1_1fcd.html", [
        [ "gr::fcdproplus::fcd_impl", "classgr_1_1fcdproplus_1_1fcd__impl.html", null ]
      ] ]
    ] ]
];