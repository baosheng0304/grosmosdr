var soapy__common_8h =
[
    [ "get_soapy_maker_mutex", "soapy__common_8h.html#a2956c43ea8f1d1ba2abfdbd74110b52b", null ],
    [ "soapy_range_to_gain_range", "soapy__common_8h.html#abc0896f8b87fdd169831cd6f9ebe2065", null ]
];