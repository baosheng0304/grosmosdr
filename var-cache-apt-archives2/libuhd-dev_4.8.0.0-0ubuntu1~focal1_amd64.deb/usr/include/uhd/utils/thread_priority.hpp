//
// Copyright 2010,2017 Ettus Research LLC
// Copyright 2018 Ettus Research, a National Instruments Company
//
// SPDX-License-Identifier: GPL-3.0-or-later
//

#pragma once
#pragma message "This header is deprecated - please use <uhd/utils/thread.hpp> instead."
#include <uhd/utils/thread.hpp>
