var files_dup =
[
    [ "api.h", "api_8h.html", "api_8h" ],
    [ "fcd.h", "fcd_8h.html", [
      [ "fcd", "classgr_1_1fcdproplus_1_1fcd.html", "classgr_1_1fcdproplus_1_1fcd" ]
    ] ],
    [ "fcd_control.h", "fcd__control_8h.html", [
      [ "fcd_control", "classgr_1_1fcdproplus_1_1fcd__control.html", "classgr_1_1fcdproplus_1_1fcd__control" ]
    ] ],
    [ "fcd_control_impl.h", "fcd__control__impl_8h.html", [
      [ "fcd_control_impl", "classgr_1_1fcdproplus_1_1fcd__control__impl.html", "classgr_1_1fcdproplus_1_1fcd__control__impl" ]
    ] ],
    [ "fcd_impl.h", "fcd__impl_8h.html", [
      [ "fcd_impl", "classgr_1_1fcdproplus_1_1fcd__impl.html", "classgr_1_1fcdproplus_1_1fcd__impl" ]
    ] ],
    [ "fcdcmd.h", "fcdcmd_8h.html", "fcdcmd_8h" ],
    [ "fcdpp_control.h", "fcdpp__control_8h.html", [
      [ "fcdpp_control", "classgr_1_1fcdproplus_1_1fcdpp__control.html", "classgr_1_1fcdproplus_1_1fcdpp__control" ]
    ] ],
    [ "fcdpp_control_impl.h", "fcdpp__control__impl_8h.html", [
      [ "fcdpp_control_impl", "classgr_1_1fcdproplus_1_1fcdpp__control__impl.html", "classgr_1_1fcdproplus_1_1fcdpp__control__impl" ]
    ] ],
    [ "fcdproplus.h", "fcdproplus_8h.html", [
      [ "fcdproplus", "classgr_1_1fcdproplus_1_1fcdproplus.html", "classgr_1_1fcdproplus_1_1fcdproplus" ]
    ] ],
    [ "fcdproplus_impl.h", "fcdproplus__impl_8h.html", [
      [ "fcdproplus_impl", "classgr_1_1fcdproplus_1_1fcdproplus__impl.html", "classgr_1_1fcdproplus_1_1fcdproplus__impl" ]
    ] ],
    [ "hidapi.h", "hidapi_8h.html", "hidapi_8h" ]
];