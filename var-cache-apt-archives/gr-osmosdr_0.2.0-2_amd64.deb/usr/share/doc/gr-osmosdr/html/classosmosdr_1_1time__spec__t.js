var classosmosdr_1_1time__spec__t =
[
    [ "time_spec_t", "classosmosdr_1_1time__spec__t.html#a6b1ac6b1c3ba7beb17cfcbed49127ee6", null ],
    [ "time_spec_t", "classosmosdr_1_1time__spec__t.html#ad607af83a4e137f6f99d33451119ad83", null ],
    [ "time_spec_t", "classosmosdr_1_1time__spec__t.html#ab856545eecf307fa65d68f3b1f7921d6", null ],
    [ "from_ticks", "classosmosdr_1_1time__spec__t.html#aaa441cad24d47c78b617c972868acca8", null ],
    [ "get_frac_secs", "classosmosdr_1_1time__spec__t.html#ab958bcf5f5d68de6cd15a270415061d3", null ],
    [ "get_full_secs", "classosmosdr_1_1time__spec__t.html#a483cd069901d1c1a4803eb72b5d6899f", null ],
    [ "get_real_secs", "classosmosdr_1_1time__spec__t.html#a96248cab64ae1e52ccdf4cc242be45ca", null ],
    [ "get_system_time", "classosmosdr_1_1time__spec__t.html#a4f35065eebe38b78785ca3618dee6490", null ],
    [ "get_tick_count", "classosmosdr_1_1time__spec__t.html#a91265cadd3880a3d97fef1d7af2d408b", null ],
    [ "operator+=", "classosmosdr_1_1time__spec__t.html#ac79732a4b0e8e9dbec609fbf35a30d15", null ],
    [ "operator-=", "classosmosdr_1_1time__spec__t.html#a007a44fb3a81aecf879754986cb8695a", null ],
    [ "to_ticks", "classosmosdr_1_1time__spec__t.html#ab9dd79693a777a0c28f6e2f1bc90b302", null ]
];