var group__gl =
[
    [ "gl.h", "gl_8h.html", null ],
    [ "gl_cmap.h", "gl__cmap_8h.html", null ],
    [ "gl_cmap_gen.h", "gl__cmap__gen_8h.html", null ],
    [ "gl_font.h", "gl__font_8h.html", null ],
    [ "ATTR_FORMAT", "group__gl.html#ga258941fa7002003d7c79d1ceec160afd", null ],
    [ "GLF_FLG_LCD", "group__gl.html#gacfc2b16e6b53cb6f691214170be0403a", null ],
    [ "gl_cmap_gen_func_t", "group__gl.html#gad46e9320ded58598cb6e305c9b915be9", null ],
    [ "fosphor_gl_cmap_mode", "group__gl.html#gad3a0574ba0faa35f7e3b98f2c0cb848e", [
      [ "GL_CMAP_MODE_NEAREST", "group__gl.html#ggad3a0574ba0faa35f7e3b98f2c0cb848eaf97130244cff9f8b001d0da68712cb60", null ],
      [ "GL_CMAP_MODE_BILINEAR", "group__gl.html#ggad3a0574ba0faa35f7e3b98f2c0cb848eace0f548561277a764e945a6a133f32ca", null ],
      [ "GL_CMAP_MODE_BICUBIC", "group__gl.html#ggad3a0574ba0faa35f7e3b98f2c0cb848ea0dfa3c194fcd99f88fdb4669f8e6872d", null ]
    ] ],
    [ "fosphor_gl_id", "group__gl.html#ga69e22d0e88439b4898263c6471520c84", [
      [ "GL_ID_TEX_WATERFALL", "group__gl.html#gga69e22d0e88439b4898263c6471520c84aa9e57a2edf19f6f5c9e57e4c45f2d61d", null ],
      [ "GL_ID_TEX_HISTOGRAM", "group__gl.html#gga69e22d0e88439b4898263c6471520c84a90b17fe8a5f6238a78512a29d9c16da8", null ],
      [ "GL_ID_VBO_SPECTRUM", "group__gl.html#gga69e22d0e88439b4898263c6471520c84a2bd2590bea3088a731aab7e02efbf11e", null ]
    ] ],
    [ "glf_align", "group__gl.html#ga585e1c5b299285d00c200410f3735487", [
      [ "GLF_LEFT", "group__gl.html#gga585e1c5b299285d00c200410f3735487ada042edd1204e6bf67ee7fdc84c71196", null ],
      [ "GLF_RIGHT", "group__gl.html#gga585e1c5b299285d00c200410f3735487a29208e9c29cc2009d367a898646acf46", null ],
      [ "GLF_TOP", "group__gl.html#gga585e1c5b299285d00c200410f3735487accac15f381a66b94a6bc00469bc0bcd6", null ],
      [ "GLF_BOTTOM", "group__gl.html#gga585e1c5b299285d00c200410f3735487aa596a6d99893d2c5e55ebf3925491f34", null ],
      [ "GLF_CENTER", "group__gl.html#gga585e1c5b299285d00c200410f3735487a642e9c269f29171d701cd857abbd5fa5", null ]
    ] ],
    [ "fosphor_gl_cmap_disable", "group__gl.html#ga3560cfdfca34c6f2c80db5b7ae964a76", null ],
    [ "fosphor_gl_cmap_draw_scale", "group__gl.html#gaae581028e9ec2167a458008fd4d75fb2", null ],
    [ "fosphor_gl_cmap_enable", "group__gl.html#ga6882c4338845c3c8306b7445fdf12bad", null ],
    [ "fosphor_gl_cmap_generate", "group__gl.html#ga1a843c320898fbba09aef378aafe6eb9", null ],
    [ "fosphor_gl_cmap_histogram", "group__gl.html#ga30ebbf227145fc1e6e6999c0002d0270", null ],
    [ "fosphor_gl_cmap_init", "group__gl.html#gaeab9abc6abc1196c40bfde59e18b75ed", null ],
    [ "fosphor_gl_cmap_release", "group__gl.html#ga709725662dcd8e8c5997732692004e00", null ],
    [ "fosphor_gl_cmap_waterfall", "group__gl.html#ga9bc370d31d6e362d66fe5bf9c6ada522", null ],
    [ "fosphor_gl_draw", "group__gl.html#gaafca1dd7081a6eb876c05836981b50c1", null ],
    [ "fosphor_gl_get_shared_id", "group__gl.html#gae2bacad5995398a0c15bd3885f2e06e1", null ],
    [ "fosphor_gl_init", "group__gl.html#ga95c02994262c0e426c7ac3a3dd80b201", null ],
    [ "fosphor_gl_refresh", "group__gl.html#gaecd4686ce841cbd6740fa4684b1f2dcd", null ],
    [ "fosphor_gl_release", "group__gl.html#ga492e62827128d897d47b8373ae0f6835", null ],
    [ "glf_alloc", "group__gl.html#gaeffa054b3814734d97b3093443a33a04", null ],
    [ "glf_begin", "group__gl.html#ga7172711005b687735a05861c43e7edce", null ],
    [ "glf_draw_str", "group__gl.html#ga9b4a6741ba6db3f732e63b79e30de746", null ],
    [ "glf_end", "group__gl.html#ga1d2abd0f6d26762e455d1aa1b5ec67ae", null ],
    [ "glf_free", "group__gl.html#gac32f8d428b04059a4f38a22f0241bd3d", null ],
    [ "glf_load_face_file", "group__gl.html#ga1ec13b7d5427e37cb6c2edc05e70f1e5", null ],
    [ "glf_load_face_mem", "group__gl.html#ga5016ec5fb2c3ff1a1ba1d4d6f8380451", null ],
    [ "glf_printf", "group__gl.html#ga418da7befbcb3a8bc61c41d9112d2325", null ],
    [ "glf_width_str", "group__gl.html#ga1d309e7548fd0db0cd7684b7713360ea", null ]
];