var classgr_1_1fcdproplus_1_1fcdproplus__impl =
[
    [ "fcdproplus_impl", "classgr_1_1fcdproplus_1_1fcdproplus__impl.html#af5600a501a95ef3aa0cca33fcb22819d", null ],
    [ "~fcdproplus_impl", "classgr_1_1fcdproplus_1_1fcdproplus__impl.html#a4830e2af49e2f1cd2f0b58903ff0fd69", null ],
    [ "set_freq", "classgr_1_1fcdproplus_1_1fcdproplus__impl.html#a734fbbf5e52b2782012eb9c3cd76e51d", null ],
    [ "set_freq_corr", "classgr_1_1fcdproplus_1_1fcdproplus__impl.html#a41415b4f9daf64e7a0d378e47f1c448b", null ],
    [ "set_if_gain", "classgr_1_1fcdproplus_1_1fcdproplus__impl.html#aa1e44da35ea983902849ef48a8590ef8", null ],
    [ "set_lna", "classgr_1_1fcdproplus_1_1fcdproplus__impl.html#a34dc8b14252bf76f729d379ec260d512", null ],
    [ "set_mixer_gain", "classgr_1_1fcdproplus_1_1fcdproplus__impl.html#ad491b9b81af03bb3893ce8ab004a41d3", null ]
];