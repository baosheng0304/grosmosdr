Qt Creator custom wizards are located in this directory.

The command line option -customwizard-verbose can be used to obtain
verbose information while loading the custom wizards.
