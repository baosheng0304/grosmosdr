var annotated_dup =
[
    [ "gr", "namespacegr.html", "namespacegr" ],
    [ "_cl_image_desc", "struct__cl__image__desc.html", "struct__cl__image__desc" ],
    [ "fosphor", "structfosphor.html", "structfosphor" ],
    [ "fosphor_channel", "structfosphor__channel.html", "structfosphor__channel" ],
    [ "fosphor_render", "structfosphor__render.html", "structfosphor__render" ],
    [ "freq_axis", "structfreq__axis.html", "structfreq__axis" ],
    [ "llist_head", "structllist__head.html", "structllist__head" ],
    [ "resource_cache", "structresource__cache.html", "structresource__cache" ],
    [ "resource_pack", "structresource__pack.html", "structresource__pack" ]
];