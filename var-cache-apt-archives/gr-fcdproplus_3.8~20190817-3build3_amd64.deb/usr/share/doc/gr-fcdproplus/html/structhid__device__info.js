var structhid__device__info =
[
    [ "interface_number", "structhid__device__info.html#a9163d8d5d7db8dc47bddfaf876e17547", null ],
    [ "manufacturer_string", "structhid__device__info.html#a484eebf746220cd2910954cc861759b7", null ],
    [ "next", "structhid__device__info.html#a2bfebc240baf3bdaf03965816e11f149", null ],
    [ "path", "structhid__device__info.html#a6384b5bf4d9583598e5f5a889f240921", null ],
    [ "product_id", "structhid__device__info.html#a04595915457b4374492edb1fdb62d65d", null ],
    [ "product_string", "structhid__device__info.html#aceee256b4f7cd7fdd9fa5d556f49d221", null ],
    [ "release_number", "structhid__device__info.html#a6a832d25260f7ec17ef008e53e50e1d0", null ],
    [ "serial_number", "structhid__device__info.html#a80756cea367e1566f966438984b75faf", null ],
    [ "usage", "structhid__device__info.html#a47f8011d58bcddd67f1403d6d3b4cab6", null ],
    [ "usage_page", "structhid__device__info.html#ab811117f8084ce2036815bdd33b16b3b", null ],
    [ "vendor_id", "structhid__device__info.html#a5037a3914e0bd8a3f821d1be9376c709", null ]
];