/* This file is auto generated, version 145~20.04.1-Ubuntu */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#145~20.04.1-Ubuntu SMP Mon Feb 17 13:27:16 UTC 2025"
#define LINUX_COMPILE_BY "buildd"
#define LINUX_COMPILE_HOST "lcy02-amd64-092"
#define LINUX_COMPILER "gcc (Ubuntu 9.4.0-1ubuntu1~20.04.2) 9.4.0, GNU ld (GNU Binutils for Ubuntu) 2.34"
