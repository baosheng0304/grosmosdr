var classgr_1_1fcdproplus_1_1fcdpp__control =
[
    [ "sptr", "classgr_1_1fcdproplus_1_1fcdpp__control.html#a1be626cfe8b520116ccbadf41eaf934b", null ],
    [ "make", "classgr_1_1fcdproplus_1_1fcdpp__control.html#ad7d67114483493b2cdf3e6c6e824915a", null ],
    [ "set_freq", "classgr_1_1fcdproplus_1_1fcdpp__control.html#a4e9e8fc226691f04d1823cf5e940ef45", null ],
    [ "set_if_gain", "classgr_1_1fcdproplus_1_1fcdpp__control.html#a3a1d9a9e902e019350b85c577f89b6c5", null ],
    [ "set_lna", "classgr_1_1fcdproplus_1_1fcdpp__control.html#ada04e1ce08422b3813d2572e52b0cd98", null ],
    [ "set_mixer_gain", "classgr_1_1fcdproplus_1_1fcdpp__control.html#a31f7e84858d69f85f2ca0b3328facb6b", null ]
];