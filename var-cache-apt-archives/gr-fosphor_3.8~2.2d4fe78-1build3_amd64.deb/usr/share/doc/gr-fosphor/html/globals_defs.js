var globals_defs =
[
    [ "_", "globals_defs.html", null ],
    [ "a", "globals_defs_a.html", null ],
    [ "b", "globals_defs_b.html", null ],
    [ "c", "globals_defs_c.html", null ],
    [ "e", "globals_defs_e.html", null ],
    [ "f", "globals_defs_f.html", null ],
    [ "g", "globals_defs_g.html", null ],
    [ "l", "globals_defs_l.html", null ],
    [ "q", "globals_defs_q.html", null ],
    [ "r", "globals_defs_r.html", null ],
    [ "s", "globals_defs_s.html", null ],
    [ "u", "globals_defs_u.html", null ]
];