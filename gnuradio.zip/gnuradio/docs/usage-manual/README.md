To export the usage manual off the wiki and update the snapshot stored in the repo:
* pip install selenium
* download the latest version of geckodriver form here https://github.com/mozilla/geckodriver/releases
* extract/move it into /usr/local/bin
* python export-usage-manual.py
* the usage manual text files in this directory should now be updated
