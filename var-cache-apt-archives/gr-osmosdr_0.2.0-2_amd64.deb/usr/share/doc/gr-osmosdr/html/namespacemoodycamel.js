var namespacemoodycamel =
[
    [ "spsc_sema", "namespacemoodycamel_1_1spsc__sema.html", "namespacemoodycamel_1_1spsc__sema" ],
    [ "BlockingReaderWriterQueue", "classmoodycamel_1_1BlockingReaderWriterQueue.html", "classmoodycamel_1_1BlockingReaderWriterQueue" ],
    [ "ReaderWriterQueue", "classmoodycamel_1_1ReaderWriterQueue.html", "classmoodycamel_1_1ReaderWriterQueue" ],
    [ "weak_atomic", "classmoodycamel_1_1weak__atomic.html", "classmoodycamel_1_1weak__atomic" ]
];