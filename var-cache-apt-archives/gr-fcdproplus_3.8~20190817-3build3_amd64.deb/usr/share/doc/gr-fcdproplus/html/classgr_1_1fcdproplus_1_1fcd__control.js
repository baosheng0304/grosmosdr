var classgr_1_1fcdproplus_1_1fcd__control =
[
    [ "sptr", "classgr_1_1fcdproplus_1_1fcd__control.html#a83d0f58b3e741c3798661088d267fbb4", null ],
    [ "make", "classgr_1_1fcdproplus_1_1fcd__control.html#ac754baa70ed181e967a82d95327681ca", null ],
    [ "set_dc_corr", "classgr_1_1fcdproplus_1_1fcd__control.html#a0c2a1d7d04d620d95bb583971df3821b", null ],
    [ "set_freq", "classgr_1_1fcdproplus_1_1fcd__control.html#acb918d66fa2f8d16ddc6dd5d6d165643", null ],
    [ "set_freq_corr", "classgr_1_1fcdproplus_1_1fcd__control.html#a9a2ec62db73d1684d76c64ca1dd6bce2", null ],
    [ "set_iq_corr", "classgr_1_1fcdproplus_1_1fcd__control.html#aaae944e79ae514f5b2d0c92d14b9d6a1", null ],
    [ "set_lna_gain", "classgr_1_1fcdproplus_1_1fcd__control.html#aac8ac5f461f3eaf1bb0bb5d747d55048", null ],
    [ "set_mixer_gain", "classgr_1_1fcdproplus_1_1fcd__control.html#a0206772df7745a0f6d69bf48b0084fb5", null ]
];