var pimpl_8h =
[
    [ "OSMOSDR_PIMPL_DECL", "pimpl_8h.html#adf43fb5bf39a048a292f08aa4e6386e7", null ],
    [ "OSMOSDR_PIMPL_MAKE", "pimpl_8h.html#a2b855ccb8c14a3f29abac8dad91f8d57", null ]
];