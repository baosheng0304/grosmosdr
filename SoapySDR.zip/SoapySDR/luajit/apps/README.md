To run these examples, install the following through [LuaRocks](https://luarocks.org/):

* argparse
* complex
* posix
