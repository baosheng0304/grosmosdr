var hierarchy =
[
    [ "_cl_image_desc", "struct__cl__image__desc.html", null ],
    [ "gr::fosphor::fifo", "classgr_1_1fosphor_1_1fifo.html", null ],
    [ "fosphor", "structfosphor.html", null ],
    [ "fosphor_channel", "structfosphor__channel.html", null ],
    [ "fosphor_render", "structfosphor__render.html", null ],
    [ "freq_axis", "structfreq__axis.html", null ],
    [ "llist_head", "structllist__head.html", null ],
    [ "QGLWidget", null, [
      [ "gr::fosphor::QGLSurface", "classgr_1_1fosphor_1_1QGLSurface.html", null ]
    ] ],
    [ "resource_cache", "structresource__cache.html", null ],
    [ "resource_pack", "structresource__pack.html", null ],
    [ "sync_block", null, [
      [ "gr::fosphor::base_sink_c", "classgr_1_1fosphor_1_1base__sink__c.html", [
        [ "gr::fosphor::base_sink_c_impl", "classgr_1_1fosphor_1_1base__sink__c__impl.html", [
          [ "gr::fosphor::glfw_sink_c_impl", "classgr_1_1fosphor_1_1glfw__sink__c__impl.html", null ],
          [ "gr::fosphor::qt_sink_c_impl", "classgr_1_1fosphor_1_1qt__sink__c__impl.html", null ]
        ] ],
        [ "gr::fosphor::glfw_sink_c", "classgr_1_1fosphor_1_1glfw__sink__c.html", [
          [ "gr::fosphor::glfw_sink_c_impl", "classgr_1_1fosphor_1_1glfw__sink__c__impl.html", null ]
        ] ],
        [ "gr::fosphor::qt_sink_c", "classgr_1_1fosphor_1_1qt__sink__c.html", [
          [ "gr::fosphor::qt_sink_c_impl", "classgr_1_1fosphor_1_1qt__sink__c__impl.html", null ]
        ] ]
      ] ]
    ] ]
];