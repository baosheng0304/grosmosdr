var group__API =
[
    [ "hid_open", "group__API.html#gae6910ed9f01c4a99d25539b16800e90c", null ],
    [ "hid_read", "group__API.html#ga6b820f3e72097cf7f994e33715dc7af1", null ]
];