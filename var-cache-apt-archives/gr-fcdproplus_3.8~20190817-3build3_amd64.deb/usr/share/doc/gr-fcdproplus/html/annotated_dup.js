var annotated_dup =
[
    [ "gr", "namespacegr.html", "namespacegr" ],
    [ "hid_device_info", "structhid__device__info.html", "structhid__device__info" ]
];