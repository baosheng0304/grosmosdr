var files_dup =
[
    [ "airspy_fir_kernels.h", "airspy__fir__kernels_8h.html", "airspy__fir__kernels_8h" ],
    [ "airspy_source_c.h", "airspy__source__c_8h.html", "airspy__source__c_8h" ],
    [ "airspyhf_source_c.h", "airspyhf__source__c_8h.html", "airspyhf__source__c_8h" ],
    [ "api.h", "api_8h.html", "api_8h" ],
    [ "arg_helpers.h", "arg__helpers_8h.html", "arg__helpers_8h" ],
    [ "atomicops.h", "atomicops_8h.html", "atomicops_8h" ],
    [ "bladerf_common.h", "bladerf__common_8h.html", "bladerf__common_8h" ],
    [ "bladerf_compat.h", "bladerf__compat_8h.html", null ],
    [ "bladerf_sink_c.h", "bladerf__sink__c_8h.html", "bladerf__sink__c_8h" ],
    [ "bladerf_source_c.h", "bladerf__source__c_8h.html", "bladerf__source__c_8h" ],
    [ "config.h", "config_8h.html", "config_8h" ],
    [ "device.h", "device_8h.html", "device_8h" ],
    [ "fcd_source_c.h", "fcd__source__c_8h.html", "fcd__source__c_8h" ],
    [ "file_sink_c.h", "file__sink__c_8h.html", "file__sink__c_8h" ],
    [ "file_source_c.h", "file__source__c_8h.html", "file__source__c_8h" ],
    [ "freesrp_common.h", "freesrp__common_8h.html", [
      [ "freesrp_common", "classfreesrp__common.html", "classfreesrp__common" ]
    ] ],
    [ "freesrp_sink_c.h", "freesrp__sink__c_8h.html", "freesrp__sink__c_8h" ],
    [ "freesrp_source_c.h", "freesrp__source__c_8h.html", "freesrp__source__c_8h" ],
    [ "hackrf_common.h", "hackrf__common_8h.html", "hackrf__common_8h" ],
    [ "hackrf_sink_c.h", "hackrf__sink__c_8h.html", "hackrf__sink__c_8h" ],
    [ "hackrf_source_c.h", "hackrf__source__c_8h.html", "hackrf__source__c_8h" ],
    [ "miri_source_c.h", "miri__source__c_8h.html", "miri__source__c_8h" ],
    [ "osmosdr_src_c.h", "osmosdr__src__c_8h.html", "osmosdr__src__c_8h" ],
    [ "pimpl.h", "pimpl_8h.html", "pimpl_8h" ],
    [ "ranges.h", "ranges_8h.html", "ranges_8h" ],
    [ "readerwriterqueue.h", "readerwriterqueue_8h.html", "readerwriterqueue_8h" ],
    [ "redpitaya_common.h", "redpitaya__common_8h.html", "redpitaya__common_8h" ],
    [ "redpitaya_sink_c.h", "redpitaya__sink__c_8h.html", "redpitaya__sink__c_8h" ],
    [ "redpitaya_source_c.h", "redpitaya__source__c_8h.html", "redpitaya__source__c_8h" ],
    [ "rfspace_source_c.h", "rfspace__source__c_8h.html", "rfspace__source__c_8h" ],
    [ "rtl_source_c.h", "rtl__source__c_8h.html", "rtl__source__c_8h" ],
    [ "rtl_tcp_source_c.h", "rtl__tcp__source__c_8h.html", "rtl__tcp__source__c_8h" ],
    [ "rtl_tcp_source_f.h", "rtl__tcp__source__f_8h.html", "rtl__tcp__source__f_8h" ],
    [ "sdrplay_source_c.h", "sdrplay__source__c_8h.html", "sdrplay__source__c_8h" ],
    [ "sink.h", "sink_8h.html", null ],
    [ "sink_iface.h", "sink__iface_8h.html", [
      [ "sink_iface", "classsink__iface.html", "classsink__iface" ]
    ] ],
    [ "sink_impl.h", "sink__impl_8h.html", [
      [ "sink_impl", "classsink__impl.html", "classsink__impl" ]
    ] ],
    [ "soapy_common.h", "soapy__common_8h.html", "soapy__common_8h" ],
    [ "soapy_sink_c.h", "soapy__sink__c_8h.html", "soapy__sink__c_8h" ],
    [ "soapy_source_c.h", "soapy__source__c_8h.html", "soapy__source__c_8h" ],
    [ "source.h", "source_8h.html", null ],
    [ "source_iface.h", "source__iface_8h.html", [
      [ "source_iface", "classsource__iface.html", "classsource__iface" ]
    ] ],
    [ "source_impl.h", "source__impl_8h.html", [
      [ "source_impl", "classsource__impl.html", "classsource__impl" ]
    ] ],
    [ "time_spec.h", "time__spec_8h.html", "time__spec_8h" ],
    [ "uhd_sink_c.h", "uhd__sink__c_8h.html", "uhd__sink__c_8h" ],
    [ "uhd_source_c.h", "uhd__source__c_8h.html", "uhd__source__c_8h" ]
];