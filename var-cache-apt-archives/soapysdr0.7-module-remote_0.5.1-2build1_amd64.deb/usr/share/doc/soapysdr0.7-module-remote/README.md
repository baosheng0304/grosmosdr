# Use any Soapy SDR remotely

## Build Status

- Travis: [![Travis Build Status](https://travis-ci.org/pothosware/SoapyRemote.svg?branch=master)](https://travis-ci.org/pothosware/SoapyRemote)

## Dependencies

* SoapySDR - https://github.com/pothosware/SoapySDR/wiki

## Documentation

* https://github.com/pothosware/SoapyRemote/wiki

## Licensing information

Use, modification and distribution is subject to the Boost Software
License, Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at
http://www.boost.org/LICENSE_1_0.txt)
